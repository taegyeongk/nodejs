<template>
  <div class="container">
    <p class="text-start">도서 관리 프로그램입니다.</p>
    <p class="text-start">
      * 각 메뉴를 참고해서 원하는 기능을 선택하시면 됩니다.
    </p>
  </div>
</template>
<script>
export default {
    name: 'Main'
}
</script>
